
Welcome to the i3pystatus documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 4

   configuration
   i3pystatus
   changelog
   module
   i3pystatus.core


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

